@echo off
start .\WebPageSaver\WebPageSaver.exe
